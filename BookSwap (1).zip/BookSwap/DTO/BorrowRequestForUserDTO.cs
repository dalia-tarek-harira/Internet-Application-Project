﻿namespace BookSwap.DTO
{
    public class BorrowRequestForUserDTO
    {
    }
}
