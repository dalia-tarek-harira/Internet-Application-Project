﻿namespace BookSwap.DTO
{
    public class LikeDTO
    {

  
        public int BookPostId { get; set; }
        public bool ReactionType { get; set; }



    }
}
